﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Linq;


namespace Aclara.Models
{
    public class SubmitIdea
    {
        public int ID { get; set; }
        [Required, StringLength(40), Display(Name = "User Name")]
        public string UserName { get; set; }
        [Required, StringLength(40), Display(Name = "Idea Title")]
        public string IdeaTitle { get; set; }
        [Required, StringLength(40), Display(Name = "Product Type")]
        public string ProductType { get; set; }
        [System.ComponentModel.DataAnnotations.DataType(System.ComponentModel.DataAnnotations.DataType.MultilineText)]
        [Required, MaxLength(1000), Display(Name = "Summary Of Idea")]
        public string Text { get; set; }
       
    }
}
