﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace Aclara.Models
{
    public class Library
    {
        public int ID { get; set; }
        [Required, StringLength(40), Display(Name = "Book Title")]
        public string Title { get; set; }
        [Required, StringLength(40), Display(Name = "Book Type")]
        public string Type { get; set; }
        [Required, StringLength(40), Display(Name = "Author (s)")]
        public string Author { get; set; }
        [Required, StringLength(40), Display(Name = "Category")]
        public string Category { get; set; }


    }
}
