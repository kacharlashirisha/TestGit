﻿using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;

namespace Aclara.Migrations
{
    public partial class Books : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Price",
                table: "Library");

            migrationBuilder.DropColumn(
                name: "ReleaseDate",
                table: "Library");

            migrationBuilder.RenameColumn(
                name: "Genre",
                table: "Library",
                newName: "Type");

            migrationBuilder.AddColumn<string>(
                name: "Author",
                table: "Library",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Category",
                table: "Library",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Author",
                table: "Library");

            migrationBuilder.DropColumn(
                name: "Category",
                table: "Library");

            migrationBuilder.RenameColumn(
                name: "Type",
                table: "Library",
                newName: "Genre");

            migrationBuilder.AddColumn<decimal>(
                name: "Price",
                table: "Library",
                nullable: false,
                defaultValue: 0m);

            migrationBuilder.AddColumn<DateTime>(
                name: "ReleaseDate",
                table: "Library",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));
        }
    }
}
