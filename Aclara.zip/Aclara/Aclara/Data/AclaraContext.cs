﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Aclara.Models;

namespace Aclara.Models
{
    public class AclaraContext : DbContext
    {
        public AclaraContext (DbContextOptions<AclaraContext> options)
            : base(options)
        {
        }

        public DbSet<Aclara.Models.SubmitIdea> SubmitIdea { get; set; }

        public DbSet<Aclara.Models.Library> Library { get; set; }

        
        
    }
}
