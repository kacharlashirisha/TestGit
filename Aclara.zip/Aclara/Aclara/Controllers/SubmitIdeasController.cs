﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Aclara.Models;

namespace Aclara.Controllers
{
    public class SubmitIdeasController : Controller
    {
        private readonly AclaraContext _context;

        public SubmitIdeasController(AclaraContext context)
        {
            _context = context;
        }

        // GET: SubmitIdeas
        public async Task<IActionResult> Index()
        {
            return View(await _context.SubmitIdea.ToListAsync());
        }

        // GET: SubmitIdeas/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var submitIdea = await _context.SubmitIdea
                .SingleOrDefaultAsync(m => m.ID == id);
            if (submitIdea == null)
            {
                return NotFound();
            }

            return View(submitIdea);
        }

        // GET: SubmitIdeas/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: SubmitIdeas/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("ID,UserName,IdeaTitle,ProductType,Text")] SubmitIdea submitIdea)
        {
            if (ModelState.IsValid)
            {
                _context.Add(submitIdea);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(submitIdea);
        }

        // GET: SubmitIdeas/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var submitIdea = await _context.SubmitIdea.SingleOrDefaultAsync(m => m.ID == id);
            if (submitIdea == null)
            {
                return NotFound();
            }
            return View(submitIdea);
        }

        // POST: SubmitIdeas/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("ID,UserName,IdeaTitle,ProductType,Text")] SubmitIdea submitIdea)
        {
            if (id != submitIdea.ID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(submitIdea);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!SubmitIdeaExists(submitIdea.ID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(submitIdea);
        }

        // GET: SubmitIdeas/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var submitIdea = await _context.SubmitIdea
                .SingleOrDefaultAsync(m => m.ID == id);
            if (submitIdea == null)
            {
                return NotFound();
            }

            return View(submitIdea);
        }

        // POST: SubmitIdeas/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var submitIdea = await _context.SubmitIdea.SingleOrDefaultAsync(m => m.ID == id);
            _context.SubmitIdea.Remove(submitIdea);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool SubmitIdeaExists(int id)
        {
            return _context.SubmitIdea.Any(e => e.ID == id);
        }
    }
}
